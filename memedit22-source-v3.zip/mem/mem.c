
#include "mem.h"
#include "mem_utils.h"
#include <pthread.h>
#include <dispatch/dispatch.h>

#define NUM_SEARCH_THREADS 8

#if TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR


extern kern_return_t
mach_vm_read(
             vm_map_t               map,
             mach_vm_address_t      addr,
             mach_vm_size_t         size,
             pointer_t              *data,
             mach_msg_type_number_t *data_size);

extern kern_return_t
mach_vm_read_overwrite(
             vm_map_t           target_task,
             mach_vm_address_t  address,
             mach_vm_size_t     size,
             mach_vm_address_t  data,
             mach_vm_size_t     *outsize);

extern kern_return_t
mach_vm_write(
              vm_map_t                          map,
              mach_vm_address_t                 address,
              pointer_t                         data,
              __unused mach_msg_type_number_t   size);

extern kern_return_t
mach_vm_region(
               vm_map_t                 map,
               mach_vm_offset_t         *address,
               mach_vm_size_t           *size,
               vm_region_flavor_t       flavor,
               vm_region_info_t         info,
               mach_msg_type_number_t   *count,
               mach_port_t              *object_name);

extern kern_return_t
mach_vm_region_recurse(
                       vm_map_t                 map,
                       mach_vm_address_t        *address,
                       mach_vm_size_t           *size,
                       uint32_t                 *depth,
                       vm_region_recurse_info_t info,
                       mach_msg_type_number_t   *infoCnt);

extern kern_return_t
mach_vm_protect(
                vm_map_t            map,
                mach_vm_offset_t    start,
                mach_vm_size_t      size,
                boolean_t           set_maximum,
                vm_prot_t           new_protection);

#else
#include <mach/mach_vm.h>
#endif

void all_processes(int uid) {
    int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0};
    u_int miblen = 4;
    size_t size;
    int st = sysctl(mib, miblen, NULL, &size, NULL, 0);
    struct kinfo_proc *process = malloc(size);
    st = sysctl(mib, miblen, process, &size, NULL, 0);
    if (st == 0) {
        size_t count = (size / sizeof(struct kinfo_proc));
        if (count == 0) {
            printf("no process\n");
        } else {
            printf("[pid] <uid:gid> name\n");
            for (size_t i = count - 1; i > 0; --i) {
                struct kinfo_proc proc = *(process + i);
                uid_t ruid = proc.kp_eproc.e_pcred.p_ruid;
                if ((uid == -1 && ruid < 500) ||
                    (uid >= 0 && ruid != uid)) continue;
                printf("[%d] <%d:%d> %s\n", proc.kp_proc.p_pid,
                       proc.kp_eproc.e_pcred.p_ruid, proc.kp_eproc.e_pcred.p_rgid,
                       proc.kp_proc.p_comm);
            }
        }
    } else {
        printf("process list no fetch, ret %d, errno %d\n", st, errno);
    }

    free(process);
}

mach_port_t get_task(int pid) {
    mach_port_t task = 0;
    printf("get task %d...", pid);
    kern_return_t kret = task_for_pid(mach_task_self(), pid, &task);
    if (kret == KERN_SUCCESS) { printf("ok\n"); }
    else { printf("no work\n"); }
    return task;
}

vm_map_offset_t get_base_address(mach_port_t task) {
    printf("get base address...");
    vm_map_offset_t vmoffset = 0;
    vm_map_size_t vmsize = 0;
    uint32_t nesting_depth = 0;
    struct vm_region_submap_info_64 vbr;
    mach_msg_type_number_t vbrcount = 16;
    kern_return_t kret = mach_vm_region_recurse(task, &vmoffset, &vmsize, &nesting_depth, (vm_region_recurse_info_t)&vbr, &vbrcount);
    if (kret == KERN_SUCCESS) {
        printf("%016llX %lld bytes.\n", vmoffset, vmsize);
    } else {
        printf("no work\n");
    }
    return vmoffset;
}

void read_mem(mach_port_t task) {
    mach_vm_offset_t address = 0;
    mach_vm_size_t region_size = 0;
    vm_region_flavor_t flavor = VM_REGION_BASIC_INFO_64;
    mach_port_t object_name = 0;
    vm_region_basic_info_data_64_t info;
    mach_msg_type_number_t info_count = VM_REGION_BASIC_INFO_COUNT_64;

    kern_return_t kret = mach_vm_region(task, &address, &region_size, flavor, (vm_region_info_t)&info, &info_count, &object_name);
    while (kret == KERN_SUCCESS) {
        vm_prot_t protection = info.protection;

        char r = (protection & VM_PROT_READ) ? 'r' : '-';
        char w = (protection & VM_PROT_WRITE) ? 'w' : '-';
        char x = (protection & VM_PROT_EXECUTE) ? 'x' : '-';
        printf("region: %016llX %c%c%c %llu bytes\n", address, r, w, x, region_size);

        void *data = malloc(region_size);
        mach_vm_size_t data_size = 0;
        kern_return_t kret_read = mach_vm_read_overwrite(task, address, region_size, (mach_vm_address_t)data, &data_size);
        if (kret_read == KERN_SUCCESS) {
            print_mem(data, data_size);
        }
        address += region_size;
        kret = mach_vm_region(task, &address, &region_size, flavor, (vm_region_info_t)&info, &info_count, &object_name);
    }
}

void *read_range_mem(mach_port_t task, mach_vm_address_t address, int forward, int backward, mach_vm_address_t *ret_address, mach_vm_size_t *ret_data_size) {
    mach_vm_offset_t region_address = address < forward ? address : address - forward;
    mach_vm_size_t region_size = 0;
    vm_region_flavor_t flavor = VM_REGION_BASIC_INFO_64;
    mach_port_t object_name = 0;
    vm_region_basic_info_data_64_t info;
    mach_msg_type_number_t info_count = VM_REGION_BASIC_INFO_COUNT_64;

    kern_return_t kret = mach_vm_region(task, &region_address, &region_size, flavor, (vm_region_info_t)&info, &info_count, &object_name);
    if (kret == KERN_SUCCESS) {
        mach_vm_address_t a = 0;
        mach_vm_size_t f = 0;
        mach_vm_size_t b = 0;
        if ((address < region_address) ||
            (address > region_address + region_size) ||
            (forward == 0 && backward == 0)) {
            f = 0;
            b = (region_size < backward || backward == 0) ? region_size : backward;
            a = region_address;
        } else {
            f = address - region_address;
            if (f > forward) f = forward;
            b = region_address + region_size - address;
            if (b > backward) b = backward;
            a = address - f;
        }

        mach_vm_size_t size = f + b;
        void *data = malloc(size);
        mach_vm_size_t data_size = 0;
        kern_return_t kret_read = mach_vm_read_overwrite(task, a, size, (mach_vm_address_t)data, &data_size);
        if (kret_read == KERN_SUCCESS) {
            if (ret_address) *ret_address = a;
            if (ret_data_size) *ret_data_size = data_size;
            return data;
        }
    }
    return NULL;
}

int read_region(mach_port_t task, mach_vm_address_t address, vm_region_basic_info_data_64_t *region_info) {
    mach_vm_size_t region_size = 0;
    vm_region_flavor_t flavor = VM_REGION_BASIC_INFO_64;
    mach_port_t object_name = 0;
    vm_region_basic_info_data_64_t info;
    mach_msg_type_number_t info_count = VM_REGION_BASIC_INFO_COUNT_64;

    kern_return_t kret = mach_vm_region(task, &address, &region_size, flavor, (vm_region_info_t)&info, &info_count, &object_name);
    if (kret != KERN_SUCCESS) return -1;
    if (region_info) *region_info = info;
    return 1;
}

int write_mem(mach_port_t task, mach_vm_address_t address, void *value, int size) {
    vm_region_basic_info_data_64_t info;
    int ret = read_region(task, address, &info);
    if (ret != 1) return -1;
    kern_return_t kret = mach_vm_protect(task, address, size, FALSE, VM_PROT_WRITE | VM_PROT_READ | VM_PROT_COPY);
    if (kret != KERN_SUCCESS) { task_resume(task); return -3; }
    kret = mach_vm_write(task, address, (pointer_t)value, size);
    if (kret != KERN_SUCCESS) { task_resume(task); return -4; }
    kret = mach_vm_protect(task, address, size, FALSE, info.protection);
    if (kret != KERN_SUCCESS) { task_resume(task); return -5; }
    return 1;
}

typedef struct memory_region {
    mach_vm_offset_t address;
    mach_vm_size_t size;
    vm_prot_t protection;
    struct memory_region *next;
} memory_region_t;

typedef struct {
    mach_port_t task;
    void *value;
    int value_size;
    int value_type;
    int comparison;
    memory_region_t *regions;
    int region_count;
    search_result_chain_t results;
    pthread_mutex_t *result_mutex;
    pthread_mutex_t *progress_mutex;
    int *progress_counter;
    int total_regions;
    search_progress_callback_t progress_callback;
    void *user_data;
} thread_search_context_t;

void free_memory_regions(memory_region_t *head) {
    while (head) {
        memory_region_t *next = head->next;
        free(head);
        head = next;
    }
}

void *search_thread_worker(void *arg) {
    thread_search_context_t *ctx = (thread_search_context_t *)arg;
    search_result_chain_t local_chain = NULL;
    search_result_chain_t chain_tail = NULL;

    memory_region_t *region = ctx->regions;
    while (region) {
        mach_vm_offset_t address = region->address;
        mach_vm_size_t region_size = region->size;
        vm_prot_t protection = region->protection;

        void *data = malloc(region_size);
        mach_vm_size_t data_size = 0;

        kern_return_t kret_read = mach_vm_read_overwrite(ctx->task, address, region_size, (mach_vm_address_t)data, &data_size);
        if (kret_read == KERN_SUCCESS) {
            void *big = data;
            int64_t big_size = data_size;
            void *result = NULL;

            do {
                result = search_mem_value(big, big_size, ctx->value, ctx->value_size, ctx->value_type, ctx->comparison);
                if (result == NULL) break;

                mach_vm_address_t result_address_slide = (mach_vm_address_t)result - (mach_vm_address_t)data;
                mach_vm_address_t result_address = address + result_address_slide;
                big = result + ctx->value_size;
                big_size = data_size - result_address_slide - ctx->value_size;

                search_result_chain_t c = create_search_result_chain(result_address, ctx->value, ctx->value_size, ctx->value_type, protection);
                if (local_chain == NULL) {
                    local_chain = c;
                    chain_tail = c;
                } else {
                    chain_tail->next = c;
                    chain_tail = c;
                }
            } while (big_size >= ctx->value_size);
        }
        free(data);

        if (ctx->progress_callback && ctx->progress_mutex) {
            pthread_mutex_lock(ctx->progress_mutex);
            (*ctx->progress_counter)++;
            int current = *ctx->progress_counter;
            pthread_mutex_unlock(ctx->progress_mutex);

            ctx->progress_callback(current, ctx->total_regions, ctx->user_data);
        }

        region = region->next;
    }

    if (local_chain && ctx->result_mutex) {
        pthread_mutex_lock(ctx->result_mutex);
        if (ctx->results == NULL) {
            ctx->results = local_chain;
        } else {
            search_result_chain_t tail = ctx->results;
            while (tail->next) tail = tail->next;
            tail->next = local_chain;
        }
        pthread_mutex_unlock(ctx->result_mutex);
    }

    return NULL;
}

search_result_chain_t search_mem_first_with_progress(mach_port_t task, void *value, int size, int type, int comparison, int *length, search_progress_callback_t progress_callback, void *user_data) {
    mach_vm_offset_t address = 0;
    mach_vm_size_t region_size = 0;
    vm_region_flavor_t flavor = VM_REGION_BASIC_INFO_64;
    mach_port_t object_name = 0;
    vm_region_basic_info_data_64_t info;
    mach_msg_type_number_t info_count = VM_REGION_BASIC_INFO_COUNT_64;

    memory_region_t *region_list_head = NULL;
    memory_region_t *region_list_tail = NULL;
    int total_regions = 0;

    kern_return_t kret = KERN_FAILURE;
    do {
        address += region_size;
        info_count = VM_REGION_BASIC_INFO_COUNT_64;
        kret = mach_vm_region(task, &address, &region_size, flavor, (vm_region_info_t)&info, &info_count, &object_name);
        if (kret != KERN_SUCCESS) break;

        memory_region_t *region = (memory_region_t *)malloc(sizeof(memory_region_t));
        region->address = address;
        region->size = region_size;
        region->protection = info.protection;
        region->next = NULL;

        if (region_list_head == NULL) {
            region_list_head = region;
            region_list_tail = region;
        } else {
            region_list_tail->next = region;
            region_list_tail = region;
        }
        total_regions++;
    } while (1);

    if (total_regions == 0) {
        if (length) *length = 0;
        return NULL;
    }

    int regions_per_thread = (total_regions + NUM_SEARCH_THREADS - 1) / NUM_SEARCH_THREADS;
    pthread_t threads[NUM_SEARCH_THREADS];
    thread_search_context_t contexts[NUM_SEARCH_THREADS];
    pthread_mutex_t result_mutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_t progress_mutex = PTHREAD_MUTEX_INITIALIZER;
    int progress_counter = 0;
    search_result_chain_t global_results = NULL;

    memory_region_t *current_region = region_list_head;
    int thread_count = 0;

    for (int i = 0; i < NUM_SEARCH_THREADS && current_region != NULL; i++) {
        contexts[i].task = task;
        contexts[i].value = value;
        contexts[i].value_size = size;
        contexts[i].value_type = type;
        contexts[i].comparison = comparison;
        contexts[i].regions = current_region;
        contexts[i].region_count = 0;
        contexts[i].results = NULL;
        contexts[i].result_mutex = &result_mutex;
        contexts[i].progress_mutex = &progress_mutex;
        contexts[i].progress_counter = &progress_counter;
        contexts[i].total_regions = total_regions;
        contexts[i].progress_callback = progress_callback;
        contexts[i].user_data = user_data;

        memory_region_t *thread_last_region = current_region;
        for (int j = 0; j < regions_per_thread && current_region != NULL; j++) {
            contexts[i].region_count++;
            thread_last_region = current_region;
            current_region = current_region->next;
        }

        if (thread_last_region) {
            thread_last_region->next = NULL;
        }

        pthread_create(&threads[i], NULL, search_thread_worker, &contexts[i]);
        thread_count++;

        if (current_region) {
            contexts[i + 1].regions = current_region;
        }
    }

    for (int i = 0; i < thread_count; i++) {
        pthread_join(threads[i], NULL);
        if (contexts[i].results) {
            if (global_results == NULL) {
                global_results = contexts[i].results;
            } else {
                search_result_chain_t tail = global_results;
                while (tail->next) tail = tail->next;
                tail->next = contexts[i].results;
            }
        }
    }

    int count = 0;
    search_result_chain_t c = global_results;
    while (c) {
        count++;
        c = c->next;
    }

    free_memory_regions(region_list_head);
    pthread_mutex_destroy(&result_mutex);
    pthread_mutex_destroy(&progress_mutex);

    if (length) *length = count;
    return global_results;
}

search_result_chain_t search_mem_first(mach_port_t task, void *value, int size, int type, int comparison, int *length) {
    return search_mem_first_with_progress(task, value, size, type, comparison, length, NULL, NULL);
}

search_result_chain_t search_mem_in_chain(mach_port_t task, void *value, int size, int type, int comparison, search_result_chain_t chain, int *length) {
    int count = 0;
    search_result_chain_t head_chain = chain;
    search_result_chain_t prev_chain = NULL;
    void *data = malloc(size);
    while (chain) {
        int destroy_chain = 1;
        if (chain->result) {
            mach_vm_offset_t address = chain->result->address;
            mach_vm_size_t data_size = 0;
            kern_return_t kret_read = mach_vm_read_overwrite(task, address, size, (mach_vm_address_t)data, &data_size);
            if (kret_read == KERN_SUCCESS) {
                int r = compare_value(data, (int)data_size, value, size, type);
                int match = (comparison == SearchResultComparisonLT && r == -1) ||
                (comparison == SearchResultComparisonLE && (r == -1 || r == 0)) ||
                (comparison == SearchResultComparisonEQ && r == 0) ||
                (comparison == SearchResultComparisonGE && (r == 0 || r == 1)) ||
                (comparison == SearchResultComparisonGT && r == 1);
                if (match) {
                    destroy_chain = 0;
                    memcpy(chain->result->value, data, data_size);
                    ++count;
                }
            }
        }

        if (destroy_chain == 1) {
            if (prev_chain == NULL) {
                head_chain = chain->next;
                destroy_search_result_chain(chain);
                chain = head_chain;
            } else {
                prev_chain->next = chain->next;
                destroy_search_result_chain(chain);
                chain = prev_chain->next;
            }
        } else {
            prev_chain = chain;
            chain = chain->next;
        }
    }
    free(data);
    if (length) *length = count;
    return head_chain;
}

void review_mem_in_chain(mach_port_t task, search_result_chain_t chain) {
    while (chain) {
        if (chain->result) {
            mach_vm_offset_t address = chain->result->address;
            void *data = malloc(chain->result->size);
            mach_vm_size_t data_size = 0;

            kern_return_t kret_read = mach_vm_read_overwrite(task, address, chain->result->size, (mach_vm_address_t)data, &data_size);
            if (kret_read == KERN_SUCCESS) {
                memcpy(chain->result->value, data, data_size);
            }
            free(data);
        }
        chain = chain->next;
    }
}

search_result_chain_t search_mem(mach_port_t task, void *value, int size, int type, int comparison, search_result_chain_t chain, int *length) {
    search_result_chain_t result = NULL;
    if (chain == NULL) result = search_mem_first(task, value, size, type, comparison, length);
    else result = search_mem_in_chain(task, value, size, type, comparison, chain, length);
    return result;
}

search_result_chain_t search_mem_with_progress(mach_port_t task, void *value, int size, int type, int comparison, search_result_chain_t chain, int *length, search_progress_callback_t progress_callback, void *user_data) {
    search_result_chain_t result = NULL;
    if (chain == NULL) result = search_mem_first_with_progress(task, value, size, type, comparison, length, progress_callback, user_data);
    else result = search_mem_in_chain(task, value, size, type, comparison, chain, length);
    return result;
}

void print_mem(void *data, mach_vm_size_t data_size) {
    for (mach_vm_size_t i = 0; i < data_size; ++i) {
        if (i % 16 == 0) {
            printf("\n%016llX ", (pointer_t)data + i);
        }
        printf("%02X ", *(unsigned char *)(data+i));
    }
}
